import streamlit as st
import pandas as pd
import plotly.express as px
from calculations import assess_borrower, calculate_emi

st.set_page_config(page_title="CreditLens AI", page_icon="🔎", layout="wide")

st.markdown("""
<style>
.main {background-color: #f7f9fc;}
.block-container {padding-top: 1.6rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {background: white; padding: 16px; border: 1px solid #e4eaf2; border-radius: 14px;}
.hero {background: linear-gradient(115deg,#102a43,#176b78); color: white; padding: 24px 28px; border-radius: 18px; margin-bottom: 20px;}
.hero h1 {color:white; margin-bottom:0.2rem;}
.hero p {color:#e0f2f1; margin-bottom:0;}
.small-note {color:#526273; font-size:0.9rem;}
</style>
""", unsafe_allow_html=True)

def money(value):
    if value is None:
        return "N/A"
    return "₹" + format(round(value), ",").replace(",", ",")

def risk_style(level):
    if level == "Lower Risk":
        return "🟢", "#e0f5e9", "#176b3a"
    if level == "High Risk":
        return "🔴", "#fde8e7", "#a61b1b"
    return "🟠", "#fff2d6", "#8a5700"

if "income_values" not in st.session_state:
    st.session_state.income_values = [28000, 30000, 26000, 32000, 29000, 31000]

with st.sidebar:
    st.title("🔎 CreditLens AI")
    st.caption("See beyond the credit score")
    page = st.radio("Navigate", ["Overview", "Financial Profile", "Risk Simulator", "Data Verification"])
    st.divider()
    if st.button("Load demo borrower", use_container_width=True):
        st.session_state.income_values = [28000, 30000, 26000, 32000, 29000, 31000]
        st.session_state.demo_reset = True
        st.rerun()
    st.caption("Prototype · Not a lending decision")

st.markdown("""
<div class="hero">
  <h1>CreditLens AI</h1>
  <p>Financial Assessment &amp; Repayment Simulator</p>
  <p>Assess affordability, income stability, debt burden, evidence quality and financial stress.</p>
</div>
""", unsafe_allow_html=True)

# Inputs persist across navigation.
with st.sidebar.expander("Borrower assumptions", expanded=False):
    employment = st.selectbox("Employment type", ["Student", "Salaried", "Freelancer", "Part-time Worker", "Gig Worker", "Business Owner", "Other"], key="employment")
    evidence = st.selectbox("Evidence level", ["Mostly self-declared", "Partial evidence", "Strong supporting evidence"], index=1, key="evidence")
    essential = st.number_input("Essential monthly expenses (₹)", min_value=0, max_value=10000000, value=10000, step=500, key="essential")
    discretionary = st.number_input("Discretionary monthly expenses (₹)", min_value=0, max_value=10000000, value=4000, step=500, key="discretionary")
    formal_debt = st.number_input("Formal monthly loan repayments (₹)", min_value=0, max_value=10000000, value=2500, step=500, key="formal_debt")
    other_obligations = st.number_input("Other recurring obligations incl. informal debt (₹)", min_value=0, max_value=10000000, value=1000, step=500, key="other_obligations")
    savings = st.number_input("Available savings (₹)", min_value=0, max_value=100000000, value=40000, step=1000, key="savings")
    loan_amount = st.number_input("Proposed loan amount (₹)", min_value=0, max_value=10000000, value=50000, step=5000, key="loan_amount")
    annual_rate = st.number_input("Annual interest rate (%)", min_value=0.0, max_value=100.0, value=14.0, step=0.5, key="annual_rate")
    tenure = st.number_input("Loan tenure (months)", min_value=1, max_value=360, value=24, step=1, key="tenure")

if page == "Financial Profile":
    st.subheader("Financial Profile")
    st.write("Enter the previous six months of income. Cash income can be included, but its evidence status should be recorded accurately.")
    months = ["5 months ago", "4 months ago", "3 months ago", "2 months ago", "Last month", "This month"]
    updated = []
    cols = st.columns(3)
    for i, month in enumerate(months):
        with cols[i % 3]:
            updated.append(st.number_input(f"{month} income (₹)", min_value=0, max_value=10000000, value=int(st.session_state.income_values[i]), step=1000, key=f"income_{i}"))
    st.session_state.income_values = updated
    st.info("Tip: include income from all sources, but do not count the same payment twice. Record informal debt repayments under other recurring obligations.")
    st.subheader("Current assumptions")
    st.write(f"Employment type: **{employment}**")
    st.write(f"Evidence level: **{evidence}**")
    st.write(f"Monthly living expenses: **{money(essential + discretionary)}**")
    st.write(f"Existing monthly obligations: **{money(formal_debt + other_obligations)}**")
    st.write(f"Proposed loan: **{money(loan_amount)}** at **{annual_rate:.1f}%** for **{tenure} months**")

elif page == "Data Verification":
    st.subheader("Data Verification & Transparency")
    st.write("CreditLens separates financial affordability from how reliable the inputs appear to be.")
    st.markdown("""
    - **Self-declared:** entered by the borrower; not independently verified.
    - **Document-supported:** accompanied by a receipt, invoice, ledger or other document. This does not automatically authenticate the document.
    - **Cross-checked:** compared against an available independent source with appropriate permission.
    - **Unverified:** evidence is missing or insufficient.
    """)
    st.warning("The current prototype does not connect to banks, credit bureaus, Account Aggregator services, employers or payment providers. It cannot detect every hidden cash transaction or undisclosed loan.")
    st.subheader("Evidence checklist")
    for item in [
        "Income history recorded for six months",
        "Cash income separately identified",
        "Existing formal loan repayments disclosed",
        "Informal loans and personal borrowings disclosed",
        "Receipts, invoices or other supporting evidence reviewed where available",
        "Borrower consent obtained before any external data access",
    ]:
        st.checkbox(item, key="verify_" + item)
    st.caption("Checklist selections are for the local demo and are not an independent verification.")

else:
    income_values = st.session_state.income_values
    if page == "Risk Simulator":
        st.subheader("Financial Stress Simulator")
        c1, c2, c3 = st.columns(3)
        with c1:
            income_drop = st.slider("Income reduction", 0, 60, 20, format="%d%%")
        with c2:
            expense_increase = st.slider("Essential expense increase", 0, 50, 10, format="%d%%")
        with c3:
            unexpected = st.number_input("Unexpected monthly expense (₹)", min_value=0, max_value=1000000, value=2000, step=500)
    else:
        income_drop, expense_increase, unexpected = 20, 10, 2000

    try:
        result = assess_borrower(
            monthly_incomes=income_values,
            essential_expenses=essential,
            discretionary_expenses=discretionary,
            existing_formal_debt=formal_debt,
            other_recurring_obligations=other_obligations,
            savings=savings,
            loan_amount=loan_amount,
            annual_interest_rate=annual_rate,
            tenure_months=int(tenure),
            income_drop_percent=income_drop,
            essential_expense_increase_percent=expense_increase,
            unexpected_expense=unexpected,
            evidence_level=evidence,
        )
    except ValueError as exc:
        st.error(str(exc))
        st.stop()

    if page == "Overview":
        st.subheader("Borrower Overview")
        icon, bg, fg = risk_style(result.risk_level)
        st.markdown(f"""<div style="background:{bg};color:{fg};padding:16px 20px;border-radius:14px;margin-bottom:16px;">
        <div style="font-size:0.85rem;font-weight:600;">INDICATIVE RISK CLASSIFICATION</div>
        <div style="font-size:1.65rem;font-weight:750;">{icon} {result.risk_level}</div>
        <div>Data confidence: {result.data_confidence}</div>
        </div>""", unsafe_allow_html=True)

        row1 = st.columns(4)
        row1[0].metric("Average monthly income", money(result.average_income))
        row1[1].metric("Monthly living expenses", money(result.monthly_expenses))
        row1[2].metric("Proposed EMI", money(result.proposed_emi))
        row1[3].metric("Cash flow after EMI", money(result.cash_flow_after_loan), delta="Monthly estimate")

        row2 = st.columns(4)
        row2[0].metric("Existing monthly debt", money(result.existing_debt_payments))
        row2[1].metric("Total DTI", f"{result.total_dti_percent:.1f}%" if result.total_dti_percent is not None else "N/A")
        row2[2].metric("Income variability (CV)", f"{result.income_cv_percent:.1f}%" if result.income_cv_percent is not None else "N/A")
        row2[3].metric("Savings coverage", f"{result.savings_coverage_months:.1f} months" if result.savings_coverage_months is not None else "N/A")

        st.subheader("Why this classification?")
        for reason in result.reasons:
            st.markdown(f"- {reason}")

        st.subheader("Monthly cash-flow breakdown")
        chart_df = pd.DataFrame({
            "Category": ["Income", "Living expenses", "Existing obligations", "Proposed EMI", "Remaining buffer"],
            "Amount (₹)": [result.average_income, -result.monthly_expenses, -result.existing_debt_payments, -result.proposed_emi, result.cash_flow_after_loan]
        })
        fig = px.bar(chart_df, x="Category", y="Amount (₹)", color="Category", title="Estimated monthly cash flow")
        fig.update_layout(showlegend=False, margin=dict(l=10, r=10, t=50, b=10))
        st.plotly_chart(fig, use_container_width=True)

        income_df = pd.DataFrame({"Month": ["5 months ago", "4 months ago", "3 months ago", "2 months ago", "Last month", "This month"], "Income (₹)": income_values})
        fig2 = px.line(income_df, x="Month", y="Income (₹)", markers=True, title="Income history")
        st.plotly_chart(fig2, use_container_width=True)

    elif page == "Risk Simulator":
        st.subheader("Stress scenario results")
        st.caption("Stress testing is an illustrative scenario, not a prediction of default.")
        icon, bg, fg = risk_style(result.risk_level)
        cols = st.columns(3)
        cols[0].metric("Normal cash flow", money(result.cash_flow_after_loan))
        cols[1].metric("Stressed cash flow", money(result.stress_cash_flow), delta=money(result.stress_cash_flow - result.cash_flow_after_loan))
        cols[2].metric("Estimated EMI", money(result.proposed_emi))
        scenario_df = pd.DataFrame({
            "Scenario": ["Normal", "Stress"],
            "Cash flow (₹)": [result.cash_flow_after_loan, result.stress_cash_flow]
        })
        fig = px.bar(scenario_df, x="Scenario", y="Cash flow (₹)", color="Scenario", title="Normal vs stress scenario")
        fig.add_hline(y=0, line_dash="dash", line_color="red")
        st.plotly_chart(fig, use_container_width=True)
        if result.stress_cash_flow < 0:
            st.error("The selected stress scenario produces negative monthly cash flow. Consider reviewing the proposed loan amount and assumptions.")
        else:
            st.success("The selected stress scenario leaves a positive estimated cash-flow buffer.")
        st.write("Change the proposed loan, tenure, income or expenses in the sidebar to explore different outcomes.")

st.divider()
with st.expander("How risk levels are assigned"):
    st.write("""
    This prototype uses transparent demonstration rules based on estimated cash-flow buffer,
    income variability, debt-to-income ratio, stress-test results and evidence level.
    The rules and cut-offs are illustrative and have not been validated against real loan outcomes.
    A real lender should validate the model, test for unfair impacts, and apply its own policies
    with appropriate human oversight. Unverified information lowers confidence; it is not proof of dishonesty.
    """)
st.caption("CreditLens AI is an educational prototype. It is not an official credit score, credit decision, financial advice, or a guarantee of repayment.")
