# CreditLens AI

**Tagline:** See beyond the credit score.

CreditLens AI is a local Streamlit prototype that explores loan affordability for people with limited or irregular credit histories. It combines income history, expenses, debt obligations, a proposed EMI, stress testing, and evidence-confidence labels.

## Features

- Borrower overview dashboard with an indicative risk category: Lower Risk, Risk — Further Review, or High Risk.
- Six months of income inputs and income variability.
- EMI, debt-to-income, cash-flow, and savings-coverage calculations.
- Stress testing for income drops, increased essential expenses, and unexpected costs.
- Data verification checklist and evidence transparency.
- Explainable reasons behind the indicative risk classification.

## Run on Windows

1. Install Python 3.11 or newer from https://www.python.org/downloads/ and enable the option to add Python to PATH.
2. Open Command Prompt or PowerShell in this project folder.
3. Create a virtual environment:

   ```powershell
   python -m venv .venv
   ```

4. Activate it in Command Prompt:

   ```bat
   .venv\Scripts\activate.bat
   ```

   In PowerShell, use:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

5. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

6. Start the application:

   ```powershell
   streamlit run app.py
   ```

Streamlit should open the app in your browser. If it does not, copy the local URL shown in the terminal into your browser.

## Run tests

```powershell
python -m pytest -q
```

## Important limitations

- Risk categories are based on illustrative rules, not a validated credit-risk model.
- The app does not connect to banks, credit bureaus, Account Aggregator services, or lenders.
- It cannot detect every hidden cash transaction or undisclosed debt.
- User-entered figures are not independently verified.
- This is not an official credit score, a loan approval system, or a guarantee of repayment.
- The prototype is intended for demonstration and learning, not real lending decisions.
