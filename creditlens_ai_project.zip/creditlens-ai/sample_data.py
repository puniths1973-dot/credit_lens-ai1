"""Sample fictional borrower data for CreditLens AI demo."""
SAMPLE_BORROWER = {
    "employment_type": "Freelancer",
    "monthly_income": [28000, 30000, 26000, 32000, 29000, 31000],
    "essential_expenses": 10000,
    "discretionary_expenses": 4000,
    "formal_debt_payments": 2500,
    "other_obligations": 1000,
    "savings": 40000,
    "loan_amount": 50000,
    "annual_interest_rate": 14.0,
    "tenure_months": 24,
}
