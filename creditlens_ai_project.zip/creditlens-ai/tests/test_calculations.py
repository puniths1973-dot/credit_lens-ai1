import pytest
from calculations import calculate_emi, assess_borrower


def test_zero_interest_emi():
    assert calculate_emi(12000, 0, 12) == pytest.approx(1000)


def test_positive_interest_emi():
    emi = calculate_emi(50000, 12, 12)
    assert emi > 4000
    assert emi < 5000


def test_invalid_tenure():
    with pytest.raises(ValueError):
        calculate_emi(10000, 10, 0)


def test_negative_cash_flow_detected():
    result = assess_borrower(
        monthly_incomes=[10000] * 6,
        essential_expenses=8000,
        discretionary_expenses=2000,
        existing_formal_debt=1000,
        other_recurring_obligations=500,
        savings=1000,
        loan_amount=50000,
        annual_interest_rate=20,
        tenure_months=12,
        income_drop_percent=30,
        essential_expense_increase_percent=20,
        unexpected_expense=1000,
        evidence_level="Mostly self-declared",
    )
    assert result.cash_flow_after_loan < 0
    assert result.stress_cash_flow < 0
    assert result.risk_level == "High Risk"


def test_assessment_returns_income_average():
    result = assess_borrower(
        monthly_incomes=[10000, 12000, 14000],
        essential_expenses=3000,
        discretionary_expenses=1000,
        existing_formal_debt=0,
        other_recurring_obligations=0,
        savings=10000,
        loan_amount=0,
        annual_interest_rate=0,
        tenure_months=12,
        income_drop_percent=0,
        essential_expense_increase_percent=0,
        unexpected_expense=0,
        evidence_level="Strong supporting evidence",
    )
    assert result.average_income == pytest.approx(12000)
    assert result.cash_flow_after_loan == pytest.approx(8000)
