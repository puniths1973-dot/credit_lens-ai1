"""Core calculations for CreditLens AI.

This is an educational prototype, not a validated credit-scoring model.
"""
from dataclasses import dataclass, asdict
from typing import Sequence
import math


@dataclass
class Assessment:
    average_income: float
    minimum_income: float
    maximum_income: float
    income_cv_percent: float | None
    monthly_expenses: float
    existing_debt_payments: float
    proposed_emi: float
    total_monthly_outgoings: float
    cash_flow_before_loan: float
    cash_flow_after_loan: float
    existing_dti_percent: float | None
    total_dti_percent: float | None
    savings_coverage_months: float | None
    stress_cash_flow: float
    risk_level: str
    reasons: list[str]
    data_confidence: str

    def to_dict(self):
        return asdict(self)


def calculate_emi(principal: float, annual_rate_percent: float, months: int) -> float:
    """Calculate monthly EMI for a reducing-balance loan."""
    if principal < 0:
        raise ValueError("Loan amount cannot be negative.")
    if annual_rate_percent < 0:
        raise ValueError("Interest rate cannot be negative.")
    if months <= 0:
        raise ValueError("Loan tenure must be at least one month.")
    if principal == 0:
        return 0.0
    monthly_rate = annual_rate_percent / 1200
    if monthly_rate == 0:
        return principal / months
    factor = (1 + monthly_rate) ** months
    return principal * monthly_rate * factor / (factor - 1)


def assess_borrower(
    monthly_incomes: Sequence[float],
    essential_expenses: float,
    discretionary_expenses: float,
    existing_formal_debt: float,
    other_recurring_obligations: float,
    savings: float,
    loan_amount: float,
    annual_interest_rate: float,
    tenure_months: int,
    income_drop_percent: float = 20,
    essential_expense_increase_percent: float = 10,
    unexpected_expense: float = 0,
    evidence_level: str = "Partial evidence",
) -> Assessment:
    if not monthly_incomes:
        raise ValueError("Enter at least one monthly income value.")
    vals = list(monthly_incomes) + [
        essential_expenses, discretionary_expenses, existing_formal_debt,
        other_recurring_obligations, savings, loan_amount, annual_interest_rate,
        unexpected_expense
    ]
    if any(v < 0 for v in vals):
        raise ValueError("Financial values cannot be negative.")
    if not 0 <= income_drop_percent <= 60:
        raise ValueError("Income drop must be between 0% and 60%.")
    if not 0 <= essential_expense_increase_percent <= 50:
        raise ValueError("Expense increase must be between 0% and 50%.")

    avg_income = sum(monthly_incomes) / len(monthly_incomes)
    min_income = min(monthly_incomes)
    max_income = max(monthly_incomes)
    if avg_income > 0:
        variance = sum((x - avg_income) ** 2 for x in monthly_incomes) / len(monthly_incomes)
        cv = math.sqrt(variance) / avg_income * 100
    else:
        cv = None

    monthly_expenses = essential_expenses + discretionary_expenses
    existing_debt = existing_formal_debt + other_recurring_obligations
    emi = calculate_emi(loan_amount, annual_interest_rate, tenure_months)
    cash_before = avg_income - monthly_expenses - existing_debt
    cash_after = cash_before - emi
    total_outgoings = monthly_expenses + existing_debt + emi
    existing_dti = (existing_debt / avg_income * 100) if avg_income > 0 else None
    total_dti = ((existing_debt + emi) / avg_income * 100) if avg_income > 0 else None
    savings_coverage = (savings / total_outgoings) if total_outgoings > 0 else None

    stressed_income = avg_income * (1 - income_drop_percent / 100)
    stressed_essentials = essential_expenses * (1 + essential_expense_increase_percent / 100)
    stress_cash_flow = (
        stressed_income - stressed_essentials - discretionary_expenses
        - existing_debt - emi - unexpected_expense
    )

    reasons = []
    if avg_income <= 0:
        reasons.append("No positive average income was entered; affordability cannot be established.")
    if cash_after < 0:
        reasons.append("Estimated monthly cash flow is negative after the proposed EMI.")
    elif avg_income > 0 and cash_after / avg_income < 0.10:
        reasons.append("Less than 10% of average income remains after estimated expenses and repayments.")
    else:
        reasons.append("The current estimate leaves a positive monthly cash-flow buffer.")

    if cv is not None:
        if cv >= 35:
            reasons.append("Income varies substantially across the entered months.")
        elif cv >= 20:
            reasons.append("Income shows moderate variability across the entered months.")
        else:
            reasons.append("Income variability is relatively low in the entered months.")
    if total_dti is not None:
        if total_dti >= 40:
            reasons.append("Estimated debt repayments are high relative to average income.")
        elif total_dti >= 25:
            reasons.append("Debt repayments use a meaningful share of average income.")
        else:
            reasons.append("Estimated debt repayments use a lower share of average income.")
    if stress_cash_flow < 0:
        reasons.append("The selected stress scenario results in negative monthly cash flow.")
    if evidence_level == "Mostly self-declared":
        reasons.append("Most financial information is self-declared and not independently verified.")
    elif evidence_level == "Partial evidence":
        reasons.append("Some supporting evidence is available, but gaps remain.")
    elif evidence_level == "Strong supporting evidence":
        reasons.append("Supporting evidence is reported as relatively strong; authenticity and completeness may still require review.")

    # Transparent demo rules, not a validated lending model.
    risk_points = 0
    if avg_income <= 0 or cash_after < 0:
        risk_points += 3
    elif avg_income > 0 and cash_after / avg_income < 0.10:
        risk_points += 2
    elif avg_income > 0 and cash_after / avg_income < 0.20:
        risk_points += 1
    if cv is not None:
        if cv >= 35:
            risk_points += 2
        elif cv >= 20:
            risk_points += 1
    if total_dti is None or total_dti >= 40:
        risk_points += 2
    elif total_dti >= 25:
        risk_points += 1
    if stress_cash_flow < 0:
        risk_points += 2
    if evidence_level == "Mostly self-declared":
        risk_points += 1
    if risk_points >= 5:
        risk = "High Risk"
    elif risk_points >= 2:
        risk = "Risk — Further Review"
    else:
        risk = "Lower Risk"

    confidence = {
        "Mostly self-declared": "Low",
        "Partial evidence": "Moderate",
        "Strong supporting evidence": "Higher (not independently authenticated)",
    }.get(evidence_level, "Unknown")

    return Assessment(
        average_income=avg_income,
        minimum_income=min_income,
        maximum_income=max_income,
        income_cv_percent=cv,
        monthly_expenses=monthly_expenses,
        existing_debt_payments=existing_debt,
        proposed_emi=emi,
        total_monthly_outgoings=total_outgoings,
        cash_flow_before_loan=cash_before,
        cash_flow_after_loan=cash_after,
        existing_dti_percent=existing_dti,
        total_dti_percent=total_dti,
        savings_coverage_months=savings_coverage,
        stress_cash_flow=stress_cash_flow,
        risk_level=risk,
        reasons=reasons,
        data_confidence=confidence,
    )
